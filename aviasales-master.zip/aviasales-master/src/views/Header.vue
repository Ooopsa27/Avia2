<template>
    <div class="header">
      <img src="../assets/Logo.svg" alt="logo" />
    </div>
</template>
<script>
import logosvg from '../assets/Logo.svg'
export default {
    data() {
        return logosvg  
        }
    }
</script>