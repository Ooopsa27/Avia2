<template>
    <TicketItem></TicketItem>
</template>

<script>
import TicketItem from '../components/TicketItem.vue';
export default {
    components: {
        TicketItem,
    }
};
</script>