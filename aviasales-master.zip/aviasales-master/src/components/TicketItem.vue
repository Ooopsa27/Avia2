<template>
    <div class="card_fly">Билет вникуда</div>
</template>