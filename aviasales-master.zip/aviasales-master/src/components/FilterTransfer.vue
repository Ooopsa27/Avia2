<template>
    <div class="filter-transfer">
        <input type="checkbox"> Все
        <input type="checkbox"> Без пересадок
        <input type="checkbox"> 1 пересадка
        <input type="checkbox"> 2 пересадки
        <input type="checkbox"> 3 пересадки
    </div>
</template>